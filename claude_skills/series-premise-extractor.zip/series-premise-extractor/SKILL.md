---
name: series-premise-extractor
description: Extract narrative series premise documents into structured JSON for database loading with validation interface.
---

# Series Premise Extractor & DB Prep

## Overview

This skill systematically extracts data from narrative series premise documents into a standardized JSON structure optimized for PostgreSQL database integration. It follows a strict extraction → validation → database prep workflow with minimal LLM token usage.

**Use this Skill when you need to:**
- Extract structured data from narrative premise documents
- Prepare extracted data for PostgreSQL database insertion
- Create a validation interface for data review
- Minimize token usage during extraction

**Do NOT use this Skill for:**
- Creating actual database entries (use the output with the DB tools)
- Writing new prose content
- Creative brainstorming

---

## Process Overview

```
┌─────────────────┐     ┌────────────────┐     ┌────────────────────┐
│ 1. EXTRACTION   │────►│ 2. VALIDATION  │────►│ 3. DB PREPARATION  │
│ Fixed structure │     │ JSON Schema    │     │ SQL Generation     │
│ Minimal tokens  │     │ Web Interface  │     │ UPSERT Statements  │
└─────────────────┘     └────────────────┘     └────────────────────┘
```

---

## 1. Extraction Phase

### Fixed JSON Structure

Extract into this exact schema to ensure database compatibility:

```javascript
{
  "metadata": {
    "extraction_timestamp": "ISO-8601-timestamp",
    "source_document": "document_name",
    "extraction_version": "1.0"
  },
  "series": {
    "title": "string",
    "author_id": null,  // To be filled during validation
    "description": "string",
    "target_audience": "string",
    "status": "ongoing",  // Default value
    "start_year": null,   // To be filled during validation
    "genres": ["string", "string"]
  },
  "books": [
    {
      "series_id": null,  // To be filled by SQL script
      "title": "string",
      "book_number": 1,
      "status": "planned",
      "target_word_count": null,
      "actual_word_count": 0,
      "description": "string"
    }
  ],
  "characters": [
    {
      "series_id": null,  // To be filled by SQL script
      "name": "string",
      "full_name": "string",
      "aliases": ["string"],
      "character_type": "main",  // main, supporting, minor, antagonist
      "first_appearance_book_id": null,  // To be filled during validation
      "status": "alive"  // alive, dead, missing, unknown
    }
  ],
  "character_details": [
    {
      "character_id": null,  // To be filled by SQL script
      "category": "string",  // physical, personality, background, skills, relationships, quirks
      "attribute": "string",
      "value": "string",
      "source_book_id": null,
      "confidence_level": "established"  // established, mentioned, implied
    }
  ],
  "plot_threads": [
    {
      "series_id": null,  // To be filled by SQL script
      "title": "string",
      "description": "string",
      "thread_type_id": null,  // To be matched with lookup table
      "importance_level": 5,
      "complexity_level": 5,
      "start_book": null,
      "end_book": null,
      "related_characters": [null]  // Array of character IDs, to be filled
    }
  ],
  "locations": [
    {
      "series_id": null,  // To be filled by SQL script
      "name": "string",
      "location_type": "string",
      "description": "string",
      "parent_location_id": null,
      "climate": "string",
      "atmosphere": "string",
      "notable_features": ["string"]
    }
  ],
  "organizations": [
    {
      "series_id": null,  // To be filled by SQL script
      "name": "string",
      "organization_type": "string",
      "description": "string",
      "headquarters_location_id": null,
      "influence_level": 5,
      "status": "active"  // active, disbanded, dormant, secret
    }
  ],
  "world_systems": [
    {
      "series_id": null,  // To be filled by SQL script
      "system_name": "string",
      "system_type": "string",
      "power_source": "string",
      "access_method": "string",
      "limitations": ["string"],
      "system_rules": ["string"]
    }
  ],
  "relationship_arcs": [
    {
      "plot_thread_id": null,  // To be filled by SQL script
      "arc_name": "string",
      "participants": {},  // JSONB formatted relationship roles
      "relationship_type": "string",
      "current_dynamic": "string",
      "complexity_level": 5
    }
  ],
  "information_reveals": [
    {
      "plot_thread_id": null,  // To be filled by SQL script
      "reveal_type": "string",
      "information_content": "string",
      "reveal_method": "string",
      "significance_level": "string",
      "affects_characters": [null],  // Array of character IDs, to be filled
      "revealed_in_book": null
    }
  ],
  "validation": {
    "missing_fields": [],
    "uncertain_fields": [],
    "inferred_fields": []
  }
}
```

### Token Optimization Guidelines

1. **Single Extraction Pass:** Extract all data in one pass
2. **Fixed Categories:** Use only the categories in the schema
3. **Minimal Inference:** Only extract what's explicitly stated
4. **Mark Uncertainty:** Flag missing or uncertain data in validation object
5. **Use Direct Quotes:** For descriptions, use direct quotes from source when possible
6. **Simplify Long Text:** Summarize very long descriptions to 1-2 sentences
7. **Primitive Values:** Use primitive values for enums rather than objects

---

## 2. Validation Phase

### JSON Schema Validation

The extracted JSON is validated against a strict schema that matches the PostgreSQL database. This ensures:

1. All required fields are present
2. Field types match database requirements
3. Enum values are within valid options
4. Relationships are properly structured

### Web Interface Generation

A simple HTML/JavaScript validation interface is generated with these features:

```javascript
// Interface code to display a form with:
// 1. Tabbed sections (Series, Books, Characters, etc.)
// 2. Form fields for each attribute
// 3. Validation error highlighting
// 4. Warning indicators for uncertain/inferred data
// 5. Save/Submit button
```

### Validation Display Features

- Required fields are clearly marked
- Missing data is highlighted in red
- Uncertain data is highlighted in yellow
- Inferred data is highlighted in blue
- Dropdown menus for enum fields
- Field-level validation error messages

---

## 3. DB Preparation Phase

### SQL Generation Logic

Once validated, generate SQL statements for database insertion:

1. **Series & Books:** INSERT or UPDATE based on title match
2. **Characters:** INSERT new, match existing by name within series
3. **Relationships:** CREATE after entities exist
4. **Details & Metadata:** BULK INSERT with foreign keys
5. **Use parameterized statements:** Prevent SQL injection

### Example SQL Generation

```sql
-- Dynamic SQL generation
-- Using EXISTS checks to prevent duplicates

-- Series insertion with RETURNING
INSERT INTO series (author_id, title, description, target_audience, status)
SELECT $1, $2, $3, $4, $5
WHERE NOT EXISTS (
  SELECT 1 FROM series WHERE title = $2 AND author_id = $1
)
RETURNING id;

-- Books with series_id parameter
INSERT INTO books (series_id, title, book_number, status, description)
VALUES ($1, $2, $3, $4, $5)
ON CONFLICT (series_id, book_number)
DO UPDATE SET title = $2, status = $4, description = $5
RETURNING id;

-- Characters with dynamic params
INSERT INTO characters (series_id, name, full_name, aliases, character_type)
VALUES ($1, $2, $3, $4::text[], $5)
RETURNING id;
```

### Batch Processing

To maximize efficiency for large premises:
- Group related inserts (all character details for one character)
- Use multi-row insert syntax where possible
- Generate batch scripts that maintain referential integrity

---

## CLI Integration

This skill can be used with a command-line workflow:

```bash
# Example integration
extract_premise.sh premise.md > extraction.json
validate_extraction.js extraction.json  # Opens browser interface
# User reviews and saves
generate_sql.js validated.json > insert_script.sql
psql -h localhost -d mcp_db -f insert_script.sql
```

---

## HTML Form Interface

The generated validation form provides these key features:

1. **Tabbed Interface:** Series, Books, Characters, etc.
2. **Inline Validation:** Immediate feedback on invalid data
3. **Missing Data Flags:** Clear indicators for required data
4. **Relationship Visualization:** Shows character and plot connections
5. **Expandable Sections:** Collapsible for large premises
6. **Dark/Light Mode:** User preference support

```html
<!-- Sample form generation -->
<div class="form-section">
  <h3>Series Information</h3>
  <div class="form-group">
    <label for="series-title">Series Title*:</label>
    <input type="text" id="series-title" name="series.title" 
           value="{{series.title}}" required>
    <div class="validation-message">{{validation.series.title}}</div>
  </div>
  <!-- Additional fields -->
</div>
```

---

## Error Handling & Edge Cases

### Common Extraction Challenges

1. **Ambiguous Character Roles:** Default to "supporting" and flag for review
2. **Missing Book Numbers:** Generate sequential numbers, flag for review
3. **Implied Relationships:** Only extract explicit relationships, flag implied
4. **Uncertain Chronology:** Use book order as default timeline
5. **Contradictory Information:** Extract both versions, flag contradiction

### Validation Responses

For each error type, provide specific guidance:
- **Missing Required Field:** "Title is required for database insertion"
- **Invalid Enum Value:** "Status must be one of: ongoing, completed, hiatus"
- **Referential Integrity:** "Character must be assigned to existing series"
- **Formatting Error:** "Aliases must be comma-separated"

---

## Multi-Format Output Options

The extracted data can be output in multiple formats:

1. **JSON:** Primary output for validation
2. **SQL:** Database insertion scripts
3. **Markdown Tables:** Human-readable summaries
4. **CSV:** For spreadsheet import
5. **HTML Form:** For direct user editing

```javascript
// Format conversion functions
function jsonToSQL(json) { /* ... */ }
function jsonToMarkdown(json) { /* ... */ }
function jsonToCSV(json) { /* ... */ }
function jsonToHTMLForm(json) { /* ... */ }
```

---

## Genre-Specific Extraction Logic

Apply specialized extraction rules based on detected genre:

### Fantasy Series
- Extract magic systems with strict rulesets
- Identify world regions and governance systems
- Track fantasy races and species

### Mystery/Thriller Series
- Extract case details and crime types
- Track investigation methods and key evidence
- Identify suspect/victim relationships

### Romance Series
- Extract relationship stages and milestones
- Track emotional development points
- Identify relationship obstacles and conflicts

### Science Fiction Series
- Extract technology systems and rules
- Track worldbuilding elements like alien species
- Identify scientific concepts and premises

---

## Database Integration Notes

### PostgreSQL-Specific Optimizations

1. **JSONB Fields:** Store complex nested data in JSONB
2. **Array Types:** Use PostgreSQL array types for lists
3. **Upsert Syntax:** Use ON CONFLICT DO UPDATE syntax
4. **Transaction Blocks:** Wrap related inserts in transactions
5. **Indexing Hints:** Suggest appropriate indexes

### Sample Database Configuration

```sql
-- Docker PostgreSQL setup
CREATE DATABASE mcp_db;
\c mcp_db

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Index strategy
CREATE INDEX idx_series_title ON series(title);
CREATE INDEX idx_character_name ON characters(name);
CREATE INDEX idx_book_number ON books(series_id, book_number);
```

### MCP Integration

This skill connects with existing MCP tools:
- Use MCP-tracked book IDs for references
- Maintain compatibility with MCP schema
- Support MCP plotting and character systems

---

## Cost Optimization Strategies

### Minimizing LLM Token Usage

1. **Targeted Extraction:** Specify exactly what to extract
2. **Single-Pass Processing:** Get all data in one request
3. **Schema-First Approach:** Fixed output structure reduces tokens
4. **Minimal Explanation:** No prose discussion, just extract
5. **Template Reuse:** Standard JSON template for all extractions

### Optimizing Database Operations

1. **Prepared Statements:** Reuse query plans
2. **Bulk Operations:** Group inserts when possible
3. **Index Awareness:** Avoid operations that trigger table scans
4. **Connection Pooling:** Maintain connection for multiple operations
5. **Transaction Batching:** Group related operations

---

## Best Practices Checklist

Before extraction:
- [ ] Identify premise document type and genre
- [ ] Determine which entities are most important to extract
- [ ] Check for existing series data to update vs. create new

During extraction:
- [ ] Follow exact JSON schema structure
- [ ] Extract in a single pass to minimize tokens
- [ ] Mark all uncertain or inferred data
- [ ] Maintain data relationships (foreign keys)

After extraction:
- [ ] Validate against database schema
- [ ] Present simple interface for human verification
- [ ] Generate optimized SQL for final insertion
- [ ] Document any remaining data gaps

---

## Integration Workflow Example

```
1. User uploads premise document
   │
2. LLM performs extraction to fixed JSON structure
   │
3. JSON validated against database schema
   │
4. Interactive form generated for validation
   │
5. User reviews and approves extraction
   │
6. SQL generation script creates insertion statements
   │
7. Database updated with new/modified data
   │
8. Confirmation report shows updated entities
```

This approach minimizes LLM token usage while maximizing database integration efficiency.
